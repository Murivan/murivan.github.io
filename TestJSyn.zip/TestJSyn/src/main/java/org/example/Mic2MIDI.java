package org.example;


import be.tarsos.dsp.pitch.PitchProcessor;
import com.jsyn.ports.UnitInputPort;
import com.jsyn.unitgen.ChannelIn;
import com.jsyn.unitgen.Circuit;
import com.jsyn.unitgen.PitchDetector;
import com.softsynth.math.AudioMath;

import java.util.stream.DoubleStream;


/**
 * This class reads the microphone signal, performs a basic pitch detection and outputs corresponding MIDI messages to the specified Receiver.
 *
 * @author Axel Berndt
 */
public class Mic2MIDI extends Circuit {
    public static final double PITCH_THRESHOLD = 0.95;
    public static final int INTERVAL = 1;
    private int currentPitch = -1;
    private final ChannelIn channelIn = new ChannelIn();// microphone input

    // Tarsos
    public UnitInputPort confidence;
    public UnitInputPort pitch;
    public UnitInputPort Jpitch;

    public Mic2MIDI() {

        // Build DSP patch
        this.add(this.channelIn);// add channelIn to the synth


        // Tarsos Pitch Detector
        addPort(this.confidence = new UnitInputPort("Confidence"));
        addPort(this.pitch = new UnitInputPort("Pitch"));
        addPort(this.Jpitch = new UnitInputPort("JPitch"));

        TarsosPitchDetector tarsosPitchDetector = new TarsosPitchDetector(44100, 2048, PitchProcessor.PitchEstimationAlgorithm.DYNAMIC_WAVELET);
        tarsosPitchDetector.input.connect(0, this.channelIn.output, 0);
        tarsosPitchDetector.frequency.connect(0, this.pitch, 0);
        tarsosPitchDetector.confidence.connect(0, this.confidence, 0);

        this.add(tarsosPitchDetector);

        PitchDetector pitchDetector = new PitchDetector();
		pitchDetector.input.connect(0, this.channelIn.output, 0);
        pitchDetector.frequency.connect(0,this.Jpitch,0);
		this.add(pitchDetector);
    }

    @Override
    public void generate(int start, int limit) {
        super.generate(start, limit);

//Tarsos
        double[] confidenceInputs = this.confidence.getValues();
        double[] pitchInputs = this.pitch.getValues();
        double[] JpitchInputs = this.Jpitch.getValues();
        if (pitchInputs[0] > 0) {
            if (confidenceInputs[0] >= PITCH_THRESHOLD || confidenceInputs[0]<=-1) {
                int newPitch = (int) Math.round(AudioMath.frequencyToPitch(pitchInputs[0]));
                if ((newPitch > currentPitch + INTERVAL) || (newPitch < currentPitch - INTERVAL)) {
                    if (currentPitch != -1) {
                       // this.sendNoteOff(this.currentPitch);
                    }
                    //this.sendNoteOn(newPitch);
                    currentPitch = newPitch;
                    System.out.println(DoubleStream.of(JpitchInputs).average().getAsDouble());
                    String message = String.format("Pitch detected : %.2fHz MIDI %d ( %.2f probability)\n", pitchInputs[0], newPitch, confidenceInputs[0]);
                    System.out.println(message);
                }
            }
        } else {
            if (currentPitch != -1) {
                //this.sendNoteOff(currentPitch);
                currentPitch = -1;
            }
        }
    }

}
