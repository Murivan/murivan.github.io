package org.example;


import com.jsyn.JSyn;
import com.jsyn.Synthesizer;
import com.jsyn.devices.AudioDeviceFactory;
import com.jsyn.devices.AudioDeviceManager;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.printf("Starting synth: \r\n");
        Synthesizer synth = JSyn.createSynthesizer();
        synth.setRealTime(true);
        AudioDeviceManager audioManager = AudioDeviceFactory.createAudioDeviceManager();
        int numDevices = audioManager.getDeviceCount();

        for (int i = 0; i < numDevices; ++i){
            if (audioManager.getMaxInputChannels(i) <= 0)
                continue;
           System.out.println("[" +i +"] "+audioManager.getDeviceName(i));
        }
        int intNum = scan.nextInt();
        synth.start(44100, intNum,1,AudioDeviceManager.USE_DEFAULT_DEVICE,0);
        Mic2MIDI mic2Midi = new Mic2MIDI();
        synth.add(mic2Midi);
        mic2Midi.start();
    }
}
